package cs3500.pa01;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Represents a portion of a StudyGuide
 */
public class Section extends AbsStudyGuide {
  private final Path parent;
  private final String openBracket = "[[";
  private final String closeBracket = "]]";
  private final String heading = "#";
  BasicFileAttributes attrs;
  ArrayList<String> contents = new ArrayList<>();
  StudyGuide destination = new StudyGuide();
  private String title;
  private Scanner scan;

  /**
   * @param p : File path to be read through
   */
  public Section(Path p) {
    parent = p;
    try {
      attrs = Files.readAttributes(p, BasicFileAttributes.class);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * @param p : the path from which this section was created
   * @param title    : Heading for a section of a study guide
   * @param contents : The information in this section
   */
  public Section(Path p, String title, ArrayList<String> contents) {
    parent = p;
    try {
      attrs = Files.readAttributes(p, BasicFileAttributes.class);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
    this.title = title;
    this.contents = contents;
  }

  /**
   * Reads through the given parent file, sections information based on heading
   */
  void readFile() {
    Section temp;
    String str;
    try {
      scan = new Scanner(parent);
    } catch (IOException e) {
      e.printStackTrace();
    }
    while (scan.hasNext()) {
      str = scan.nextLine();
      if (str.startsWith(heading) && contents.size() == 0) {
        this.title = str;
      } else if (str.startsWith(heading) && contents.size() > 0) {
        temp = new Section(this.parent, this.title, this.contents);
        temp.filter();
        destination.addSection(temp);
        this.contents = new ArrayList<>();
        this.title = str;
      } else if (!scan.hasNext() && contents.size() > 0) {
        contents.add(str);
        temp = new Section(this.parent, this.title, this.contents);
        temp.filter();
        destination.addSection(temp);
      } else if (str.contains(openBracket) && !str.endsWith(closeBracket)) {
        this.multiLine(str);
      } else {
        contents.add(str);
      }
    }
    destination.writeToFile();
  }

  /**
   * @param sec : Section to compare this one to
   * @return : true if the two are equivalent, false otherwise
   */
  boolean sameSection(Section sec) {
    boolean sameSize = (this.contents.size() == sec.contents.size());
    boolean sameTitle = this.title.equals(sec.title);
    boolean sameParent = this.parent.equals(sec.parent);
    boolean flag = false;
    if (sameSize) {
      for (int i = 0; i < this.contents.size(); i++) {
        if (!this.contents.get(i).equals(sec.contents.get(i))) {
          flag = false;
          break;
        } else {
          flag = this.contents.get(i).equals(sec.contents.get(i));
        }
      }
    }
    return sameSize && sameTitle && flag && sameParent;
  }

  /**
   * @param source : string to be exploded
   * @return produces a list of characters from the given string
   */
  ArrayList<Character> explode(String source) {
    ArrayList<Character> chars = new ArrayList<>();
    for (int i = 0; i < source.length(); i++) {
      chars.add(source.charAt(i));
    }
    return chars;
  }

  public String toString() {
    return this.title + " " + this.contents.size();
  }

  /**
   * Helper for read file; handles multiline text enclosed in brackets
   *
   * @param str : the beginning of a mutli line text of importance (enclosed in [[]])
   */
  void multiLine(String str) {
    StringBuilder builder = new StringBuilder();
    ArrayList<Character> chars;
    builder.append(str);
    while (!builder.toString().endsWith(closeBracket)) {
      if (scan.hasNext()) {
        chars = this.explode(scan.nextLine());
        for (Character c : chars) {
          builder.append(c);
        }
      } else {
        contents.add(builder.toString());
        break;
      }
    }
    contents.add(builder.toString());
  }

  /**
   * Removes unimportant information from this section
   */
  private void filter() {
    ArrayList<String> temp = new ArrayList<>(this.contents);
    for (String s : temp) {
      if (!s.startsWith(heading)) {
        if (!(s.startsWith(openBracket)) && !(s.endsWith(closeBracket))) {
          contents.remove(s);
        }
      }
    }
  }

  /**
   * Writes the contents of this section to the output path
   */
  void writeToFile() {
    title += "\n";
    try {
      Files.write(output, title.getBytes(), StandardOpenOption.APPEND);
    } catch (IOException e) {
      e.printStackTrace();
    }
    for (String s : contents) {
      s += "\n";
      try {
        Files.write(output, s.getBytes(), StandardOpenOption.APPEND);
      } catch (IOException e) {
        e.printStackTrace();
      }
    }
  }
}
