package cs3500.pa01;

import java.nio.file.Path;

/**
 * Abstract class to represent the output path for a study guide
 * and its sections
 */
public abstract class AbsStudyGuide {
  Path output;

  /**
   * Initializes the output path to the one provided in Driver.main(String[] args)
   */
  public AbsStudyGuide() {
    output = Driver.outputPath;
  }
}
