package cs3500.pa01;

import org.junit.jupiter.api.Test;

class DriverTest {

  @Test
  public void fakeTest() {
  }

}