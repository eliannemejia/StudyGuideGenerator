# First Fundamental Theorem
- derivatives
- [[power rule]]
- [[differentiability]]
- [[quotient rule]]

# Second Fundamental Theorem
- [[integrals]]
- [[area between curves]] blah blah [[antiderivative]]

# Definition of the Derivative
- i hate this one
- rly annoying
- super lame