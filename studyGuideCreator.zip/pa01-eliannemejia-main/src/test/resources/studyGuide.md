
# Unit One
- [[dynamic dispatch use a lot]]
# Unit Two
- [[super cool]]
- [[function objects are useful]]
# Matrices
- [[matrix transform]]
- [[vectors are matrices]]
# Linear Regression
- [[check assumptions apply]]
- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]]
- [[symmetrical bell curve]]
# First Fundamental Theorem
- [[power rule]]
- [[differentiability]]
- [[quotient rule]]
# Second Fundamental Theorem
- [[integrals]]
- [[area between curves]] blah blah [[antiderivative]]
# Definition of the Derivative
# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices 

- [[matrix transform]] 

- [[vectors are matrices]] 

# Linear Regression 

- [[check assumptions apply]] 

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]] 

- [[symmetrical bell curve]] 

# Matrices

- [[matrix transform]]

- [[vectors are matrices]] 

# Linear Regression

- [[check assumptions apply]]

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]]

- [[symmetrical bell curve]]

null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
# Matrices
- [[matrix transform]]
- [[vectors are matrices]]
# Linear Regression
- [[check assumptions apply]]
- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]]
- [[symmetrical bell curve]]
# First Fundamental Theorem
- [[power rule]]
- [[differentiability]]
- [[quotient rule]]
# Second Fundamental Theorem
- [[integrals]]
- [[area between curves]] blah blah [[antiderivative]]
# Definition of the Derivative
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
null
null

sample text
null
