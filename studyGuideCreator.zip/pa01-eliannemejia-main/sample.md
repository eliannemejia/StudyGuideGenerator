# Matrices

- [[matrix transform]]

- [[vectors are matrices]]

# Linear Regression

- [[check assumptions apply]]

- [[sometimes valid fryuiguhojpoirdedrftiugyohiuphugftdre7s7dr8ftoydr- figuyohygtr587t98ytr589t680y7t6r5]]

- [[symmetrical bell curve]]

